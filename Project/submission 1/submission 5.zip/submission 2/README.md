# Data Visualization With d3 and Dimple

[Final visualization](https://github.com/AhmetHamzaEmra/data-visualization-with-d3-and-Dimple/tree/master/Project)


## Overview


### Visualization 3 
this chart respresent financial data. it shows were one spended.

## Feedbacks
### Dr. Kemal Aydin (North American University-Prof)

This is a nice visual representation of the financial data. Looks promising.
Right now it seems that the data is hard coded. x.addOrderRule (...)
If you can change that and read data from the file that would be great.
Keep up good work!

### Talgat Yegizbayev (Student)
waiting for feed backs 

### Behic Guven (Design Club Leader )
waiting for feed backs 